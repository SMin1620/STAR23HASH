CREATE DATABASE  IF NOT EXISTS `free` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `free`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.36.95.217    Database: free
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `room_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `is_first` bit(1) DEFAULT NULL,
  `is_read` bit(1) NOT NULL DEFAULT b'0',
  `is_reply` bit(1) NOT NULL DEFAULT b'0',
  `receiver_id` bigint NOT NULL,
  `receiver_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recent_at` datetime(6) DEFAULT NULL,
  `send_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender_id` bigint NOT NULL,
  `sender_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store` bit(1) DEFAULT b'0',
  `temporary_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (1,'2023-11-14 16:59:10.077626',_binary '\0',_binary '\0',_binary '\0',2,'뜨거운 병아리','2023-11-16 09:56:04.278052',NULL,1,'네모난 디멘터',_binary '\0','2023-11-16 09:56:04.278052'),(2,'2023-11-14 17:07:46.954568',_binary '\0',_binary '\0',_binary '\0',1,'이기적인 펭귄','2023-11-15 17:05:42.068907',NULL,4,'쿨한 표범',_binary '\0','2023-11-15 17:05:42.068907'),(3,'2023-11-14 17:25:23.570731',_binary '\0',_binary '\0',_binary '\0',1,'새하얀 삽살개','2023-11-16 17:14:02.725015',NULL,9,'성실한 진돗개',_binary '\0','2023-11-16 17:14:02.725015'),(4,'2023-11-14 17:27:01.103707',_binary '',_binary '\0',_binary '\0',7,'파파보이 여우',NULL,NULL,10,'걱정하는 패럿',_binary '\0',NULL),(5,'2023-11-14 17:32:46.880916',_binary '',_binary '\0',_binary '\0',10,'형편없는 사슴',NULL,NULL,11,'흥겨운 피글렛',_binary '\0',NULL),(6,'2023-11-14 17:34:06.538525',_binary '',_binary '\0',_binary '\0',4,'꿈이많은 삽살개',NULL,NULL,2,'미세한 코끼리',_binary '\0',NULL),(7,'2023-11-14 17:35:46.518555',_binary '',_binary '\0',_binary '\0',10,'파파걸 진돗개',NULL,NULL,13,'아늑한 코뿔소',_binary '\0',NULL),(8,'2023-11-14 17:46:52.653723',_binary '',_binary '\0',_binary '\0',14,'뻥쟁이 공작새',NULL,NULL,15,'뇌절하는 고래',_binary '\0',NULL),(9,'2023-11-14 17:56:29.786388',_binary '',_binary '\0',_binary '\0',15,'칙칙한 돌고래',NULL,NULL,16,'안경쓴 고래',_binary '\0',NULL),(10,'2023-11-14 17:59:31.943455',_binary '',_binary '\0',_binary '\0',3,'섹시한 빅풋',NULL,NULL,17,'허스키한 돌고래',_binary '\0',NULL),(11,'2023-11-14 18:13:52.420970',_binary '',_binary '\0',_binary '\0',17,'미간이넓은 자라',NULL,NULL,5,'간이큰 홍학',_binary '\0',NULL),(12,'2023-11-14 19:39:14.816043',_binary '',_binary '\0',_binary '\0',17,'허스키한 낙타',NULL,NULL,24,'방구뀌는 염소',_binary '\0',NULL),(13,'2023-11-14 20:06:45.673632',_binary '\0',_binary '\0',_binary '\0',2,'엉엉우는 표범','2023-11-16 09:56:36.621611',NULL,25,'짜증나는 살모사',_binary '\0','2023-11-16 09:56:36.621611'),(14,'2023-11-15 09:50:07.806574',_binary '\0',_binary '\0',_binary '\0',6,'기타치는 불사조','2023-11-16 15:07:30.654468',NULL,1,'젊은 족제비',_binary '\0','2023-11-16 15:07:30.654468'),(15,'2023-11-15 10:33:11.591542',_binary '',_binary '\0',_binary '\0',7,'아름다운 다람쥐',NULL,NULL,6,'만년꼴등 산토끼',_binary '\0',NULL),(16,'2023-11-15 14:34:06.158617',_binary '',_binary '\0',_binary '\0',29,'추운 하프물범',NULL,NULL,30,'옴므파탈 익룡',_binary '\0',NULL),(17,'2023-11-15 14:36:07.683670',_binary '\0',_binary '\0',_binary '\0',1,'이마가넓은 백조','2023-11-15 17:06:00.249681',NULL,29,'세련된 알파카',_binary '\0','2023-11-15 17:06:00.249681'),(18,'2023-11-15 14:44:57.213082',_binary '',_binary '\0',_binary '\0',7,'사악한 빅풋',NULL,NULL,31,'짓궂은 샐러맨더',_binary '\0',NULL),(19,'2023-11-15 16:01:19.539841',_binary '',_binary '\0',_binary '\0',31,'설사쟁이 비둘기',NULL,NULL,32,'형편없는 개구리',_binary '\0',NULL),(20,'2023-11-15 16:24:06.866602',_binary '',_binary '\0',_binary '\0',30,'소설쓰는 기러기',NULL,NULL,33,'심심한 낙타',_binary '\0',NULL),(21,'2023-11-15 17:23:13.416584',_binary '\0',_binary '\0',_binary '\0',9,'기타치는 홍학','2023-11-16 17:13:43.039256',NULL,36,'휴가간 족제비',_binary '\0','2023-11-16 17:13:43.039256'),(22,'2023-11-15 17:33:43.668605',_binary '',_binary '\0',_binary '\0',28,'섹시한 구렁이',NULL,NULL,1,'골골대는 코브라',_binary '\0',NULL),(23,'2023-11-16 09:55:05.402161',_binary '',_binary '\0',_binary '\0',19,'칙칙한 휴먼',NULL,NULL,2,'심심한 곰',_binary '\0',NULL),(24,'2023-11-16 10:00:43.904168',_binary '\0',_binary '\0',_binary '\0',6,'손이매운 두더지','2023-11-16 17:14:15.137605',NULL,11,'눈이높은 부엉이',_binary '\0','2023-11-16 17:14:15.137605'),(26,'2023-11-16 11:29:01.018409',_binary '\0',_binary '\0',_binary '\0',6,'설사쟁이 닭','2023-11-17 09:12:39.438541',NULL,5,'돈을훔치는 치타',_binary '\0','2023-11-17 12:03:49.524230'),(27,'2023-11-16 12:06:17.599531',_binary '\0',_binary '\0',_binary '\0',6,'걱정하는 당나귀','2023-11-16 17:12:45.023889',NULL,39,'똑똑한 바비루사',_binary '\0','2023-11-16 17:12:45.023889'),(28,'2023-11-16 15:32:41.936730',_binary '\0',_binary '\0',_binary '\0',6,'정직한 메추라기','2023-11-16 17:13:14.396221',NULL,40,'손톱때가낀 자라',_binary '\0','2023-11-16 17:13:14.396221'),(29,'2023-11-16 16:07:17.781571',_binary '\0',_binary '\0',_binary '\0',6,'짜증나는 너구리','2023-11-16 17:12:31.079038',NULL,42,'우등생 갑오징어',_binary '\0','2023-11-16 17:12:31.079038'),(30,'2023-11-16 16:08:42.358957',_binary '\0',_binary '\0',_binary '\0',2,'만년1등 햄스터',NULL,NULL,41,'예민한 원숭이',_binary '\0','2023-11-16 17:04:16.217523'),(31,'2023-11-16 17:17:18.060831',_binary '',_binary '\0',_binary '\0',38,'쿠키를먹는 소',NULL,NULL,6,'눈이충혈된 토끼',_binary '\0',NULL),(32,'2023-11-17 09:16:21.327927',_binary '',_binary '\0',_binary '\0',6,'똑똑한 호랑이',NULL,NULL,41,'날아가는 물개',_binary '\0',NULL),(33,'2023-11-17 09:17:31.233490',_binary '',_binary '\0',_binary '\0',6,'칙칙한 도시쥐',NULL,NULL,2,'뻥쟁이 불사조',_binary '\0',NULL),(34,'2023-11-17 09:23:33.666972',_binary '',_binary '\0',_binary '\0',25,'욕심많은 빅풋',NULL,NULL,5,'고주망태인 토끼',_binary '\0',NULL),(35,'2023-11-17 09:26:00.321806',_binary '',_binary '\0',_binary '\0',5,'옴므파탈 뱀',NULL,NULL,1,'불쌍한 삵',_binary '\0',NULL),(36,'2023-11-17 12:01:30.100763',_binary '',_binary '\0',_binary '\0',11,'앙증맞은 인면조','2023-11-17 12:01:30.100786',NULL,6,'젊은 기러기',_binary '\0',NULL),(37,'2023-11-17 12:03:01.810813',_binary '',_binary '\0',_binary '\0',20,'편안한 퓨마','2023-11-17 12:03:01.810825',NULL,36,'칙칙한 밍크',_binary '\0',NULL),(38,'2023-11-17 12:10:26.043246',_binary '',_binary '\0',_binary '\0',17,'만년1등 악어','2023-11-17 12:10:26.043253',NULL,45,'카사노바 여우',_binary '\0',NULL);
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 12:45:10
