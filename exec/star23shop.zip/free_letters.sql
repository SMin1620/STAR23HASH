CREATE DATABASE  IF NOT EXISTS `free` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `free`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.36.95.217    Database: free
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `letters`
--

DROP TABLE IF EXISTS `letters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `letters` (
  `letter_id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime(6) NOT NULL,
  `file_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hint_content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` bit(1) NOT NULL,
  `receiver_id` bigint NOT NULL,
  `sender_id` bigint NOT NULL,
  `store` bit(1) DEFAULT NULL,
  `type` int NOT NULL,
  PRIMARY KEY (`letter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `letters`
--

LOCK TABLES `letters` WRITE;
/*!40000 ALTER TABLE `letters` DISABLE KEYS */;
INSERT INTO `letters` VALUES (1,'아니 이게 맞아? 왜 빌드 되는건데','2023-11-14 16:58:48.294851','','끼잉낑',_binary '',2,1,_binary '',3),(2,'나 너무 슬퍼 승민아..\n','2023-11-14 17:12:07.637842','','ㅜㅜ',_binary '',1,5,_binary '',3),(3,'친구가업다','2023-11-14 17:25:04.141846','','짜쓱아',_binary '',6,9,_binary '',3),(4,'뀨잉\n너랑 놀구싶어\n빨리 놀자~~~\n우리 취뽀하면 오마카세 가자 어때?ㅎ','2023-11-14 18:13:03.825070','','은정이사랑행',_binary '',14,5,_binary '',3),(5,'바보 ','2023-11-14 18:25:12.625657','','워싱시',_binary '',1,20,_binary '',3),(6,'예슬이언니 정말루다가 언니랑 똑닮은 사이트를 만들었구나 엄청 귀여워 아기자기하고 어떻게 이런걸 만들었을까 ? 난 코딩이라고는 겨우 클릭버튼 만들기만 해 본 사람인데 넘넘 신기하고 멋지다 ! ! ! 나랑 다른 일을 잘하고 있는 모습이 매우매우 뿌듯하고 얼마나 고생했을지 눈물이 날 듯 ~ ~ 말 듯 ㅎㅎ ~ 여튼 우리는 모두 다 다른 일을 하고 있구나 왠지 조금 웃긴걸 . . 딱 보니 서울에 곧 올라올 것 같아 정말루 ~ 또 연휴에 보자 우 하 하 . ! ','2023-11-14 18:38:16.653751','','',_binary '',2,21,_binary '',3),(7,'와 은정언니 이거 프론트 누가했냐 미쳤네;; 개깔끔 그 잡채,,, UI개 부드럽게 잘움직이는디? 어케 했누;; 프론트 개쌉고수네 역시 내가 보는 안목이 있다니까?!','2023-11-14 20:09:26.566556','','내가 낸데 왜',_binary '',5,25,_binary '',3),(8,'하이루~ 잘 지내고 있나!! 번호 있는 사람들 찾아서 보내고 있는데 딱 마침 조회가 되는구만! 좋다좋다~ 이제 호떡 제철인데 자주 먹으러 가는감ㅋㅋㅋㅋㅋㅋㅋ ㅃ2 ','2023-11-14 20:14:06.354280','','마 같은 핵교댕깃다 아이가',_binary '\0',15,25,_binary '',3),(9,'규렬언니 하이~ 요새 잘 지내나! 아 나 mm탈퇴 되는 바람에 연락 잘 못하는게 아쉽구만~ 항상 응원하고 있습니다!! 도움 필요하면 언제든 연락하십쇼!','2023-11-14 20:17:06.416680','','이미 호칭에서 들통났쥬?',_binary '',20,25,_binary '',3),(10,'안녕 반가워 ! ','2023-11-15 10:33:01.029026','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/98fd3be9-33bc-707b-17d8-1dd5287584aa다운로드.jfif','나... 니.. 앞에있다...?',_binary '\0',11,6,_binary '',2),(11,'난 나야.','2023-11-15 10:40:50.168399','','',_binary '\0',28,28,_binary '',3),(12,'뚜룹두','2023-11-15 10:48:38.911387','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/da80bc53-9033-4300-2720-859eacf051e3IMG_1756.png','후루루',_binary '\0',11,6,_binary '',2),(13,'뚜룹두','2023-11-15 10:48:38.759717','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/da80bc53-9033-4300-2720-859eacf051e3IMG_1756.png','후루루',_binary '\0',11,6,_binary '',2),(14,'뀨잉뀨...언니...냅다 연지야를 먼저 적고 시작하면 어떡해 \n이건 익명 편지야 라고 생각했는데 생각해보니 나를 아니깐 연지야라고 부를 수 있겠구나....웃기다 시연 시나리오는 그래요...다들 그렇게 하고 나면 우리 ucc는 뭐 얘기해야할 거 아니에요..? 차선호님 출연시키고 신운님 출연시킬 거면 오늘 어? 해야지? 어?\n휴 언니 보고싶당 언니 나 디비 수정 그만하고시풔~~~! 언니 알라븅 행복','2023-11-15 16:23:17.331608','','난 너고 넌 나야~!',_binary '\0',34,33,_binary '',3),(15,'사랑해','2023-11-15 17:02:45.394153','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/57521b90-c752-97e4-ed29-0f40fa8ee0de7107A9EC-E75A-4782-8533-7F0F37343B25.jpeg','',_binary '\0',26,5,_binary '',2),(16,'귀여워','2023-11-15 17:03:33.400992','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/5a450680-84eb-9f15-8dcf-ceb708efc1ccAC4E2E1E-6CBB-4E00-8496-99FF6AF08005.jpeg','',_binary '',2,5,_binary '',2),(17,'ㅇㅅㅇ','2023-11-16 10:01:55.239913','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/e64a5f66-5f2e-5969-f105-33ce6a61d959beastmode.png','',_binary '',2,11,_binary '',2),(18,'뚜룹뚜뚜뚜룹','2023-11-16 10:02:14.992176','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/a6befb11-a2db-d33e-6ce1-cb8da13047e6다운로드.jfif','나는 카와이',_binary '',2,6,_binary '',2),(19,'나 는 귀 여 워 ! ','2023-11-16 10:03:12.762915','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/7d244e34-5466-dc5b-85b2-5e24b159e36f다운로드.jfif','귀 염 둥 이',_binary '',2,6,_binary '',2),(20,'게 이동 영상','2023-11-16 10:06:46.352011','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/b093e4c3-2624-c60c-b99c-f9483f49bb87공통PJT_부울경_1반_E103_UCC경진대회.mp4','',_binary '',2,6,_binary '',1),(21,'감자','2023-11-16 10:23:43.124517','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/6011fbb7-9c58-ce03-ff95-cddd17e76877불꽃놀이3.wav','',_binary '',2,11,_binary '',0),(22,'나 너 좋아하냐...?','2023-11-16 10:34:13.648274','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/0c0048f4-b533-40c6-d7a0-10f0a0c75147다운로드(1).jfif','',_binary '',6,5,_binary '',2),(23,'안뇽 은정아\n싸피에서 너라는 사람을 알게 되어서 너무 죠아!\n우리 싸피 끝나고도 계속 우정 이어가는거댜~~\n우리 꽃길만 걷쟈~!~!~!','2023-11-16 10:35:33.931686','','말투보고 맞춰봥 ><',_binary '',6,2,_binary '',3),(24,'안뇽 안뇽 나 누구게 맞춰봐랑 헤헤 \n꺄앙 >_<','2023-11-16 10:36:24.255014','','맞춰봥!',_binary '\0',1,2,_binary '',3),(25,'혼자 카우치 포테이토해서 미안해\n하지만 프링글스 너무 맛있는 걸\n이틀만 더 카우치 포테이토 할게 이해해줘 ^_^\n그럼 20000,,,,','2023-11-16 10:38:33.778063','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/07362aa4-d970-eba2-b7d6-97cc4045c05eimage(19).png','카우치 포테이토걸',_binary '',6,5,_binary '',2),(26,'크리스마스에 뭐해?\n나랑 영화볼래?','2023-11-16 10:43:01.303554','','커피',_binary '',6,5,_binary '',3),(27,'혹시.. 나랑 담배한대 필래..?','2023-11-16 10:43:59.557414','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/4d94fba2-30e4-631c-7a58-245bfdeab2ebnor.png','금연캠페인 공모전 대상 수상자',_binary '',6,11,_binary '',2),(28,'나 누구게ㅋ','2023-11-16 10:47:25.935311','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/dbc7f995-f381-e80b-7469-a7c91221b9ca다운로드(2).jfif','카와이네',_binary '',6,5,_binary '',2),(29,'화이팅','2023-11-16 10:48:20.209484','','',_binary '\0',1,36,_binary '',3),(30,'오리오리가오리','2023-11-16 11:02:57.272402','','',_binary '',6,5,_binary '',1),(31,'친구에게 보내기!!!!','2023-11-16 12:08:03.159801','','',_binary '',2,39,_binary '',3),(32,'꺄향 ~~~~\n너 내 도..ㄷㄷ도도독','2023-11-16 15:09:30.983836','','',_binary '',5,6,_binary '',3),(33,'규려르쟝 카와이라능','2023-11-16 15:25:19.193255','','암 유얼 펜',_binary '\0',20,6,_binary '',3),(34,'나 너 좋아해','2023-11-16 16:10:53.006694','','나 너랑 영화봤어',_binary '',5,41,_binary '',3),(35,'너 요즘 귀엽다?\n하지만 내가 더 귀여워.','2023-11-16 16:13:53.409390','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/0c46c5f4-05ad-325d-c949-c9ef975f38fd다운로드(2).jfif','뀨',_binary '',6,6,_binary '',2),(36,'이렇게 하면 널 가질 수 있을 거라 생각했어`','2023-11-16 16:14:02.924750','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/ca1a975b-499b-d763-7428-7582a75ecdca이렇게하면널.png','롤렉스시계',_binary '',6,11,_binary '',2),(37,'크리스마스에 뭐해?\n나랑 영화보러 갈래?','2023-11-16 16:14:31.805239','','우리 저때 먹었던 고기 맛있었지?',_binary '',6,6,_binary '',3),(38,'카우치 포테이토는ㄴ\n포테이토는 사랑해요\n포테이토는 양파맛이\n제일 맛있어요','2023-11-16 16:15:24.469253','','카우치 포테이토걸',_binary '',6,6,_binary '',3),(39,'나 너 좋아하냐?','2023-11-16 16:15:56.380110','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/b40a361b-f29c-d9c8-4394-be0eccd1f46a다운로드(1).jfif','',_binary '',6,6,_binary '',2),(40,'. 　。　　　　•　 　ﾟ　　。 . •　. 　。\n　　.　　　.　　　 　　.　　　　　。　　 。　.\n　.　　 . 。　 ඞ 。　 . •\n• . 싸피는 임포스터였습니다.　 。　.\n　 　　。　　　　　　ﾟ　　　.　　　　　.\n。　　　　.　 .　　 . . . 　。　　 .','2023-11-16 16:16:06.962254','','',_binary '',6,11,_binary '',3),(41,'고생했...어..','2023-11-16 16:18:15.826573','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/0ad65cc3-6760-c9c5-4d9b-a1b7551622a9sad.PNG','',_binary '',6,11,_binary '',2),(42,'안녕 예슬아 ! \n나는 내가 너무 귀여운것 같아 ','2023-11-16 16:38:30.009599','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/65afdd18-f8d8-1a4f-cc9c-1b5b4f5de3ab다운로드.jfif','나 새로 케이스 샀다',_binary '',2,6,_binary '',2),(43,'호오오오이쨔! ','2023-11-16 18:26:46.298881','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/1a913cd9-73d5-8c2f-1ef8-6967d228e60fIMG_1743.jpeg','나는 조무래기..',_binary '\0',11,6,_binary '',2),(44,'냠냠베리','2023-11-17 02:41:18.989916','','',_binary '',6,11,_binary '',3),(45,'주말에 뭐해?\n나랑 밥 막을래?\n나랑 영화 볼래?\n','2023-11-17 09:22:16.675639','','아기고앵이',_binary '\0',6,5,_binary '',2),(46,'뚜룹뚜뚜룹뚜','2023-11-17 09:25:41.977604','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/bb9ec9c4-f2e9-85a3-8890-695924432738다운로드.jfif','꺄를ㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹㄹ',_binary '\0',11,1,_binary '',2),(47,'뚜룹뚜뚜뚜룹','2023-11-17 10:00:23.463035','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/b59ea327-e3dd-c829-673c-6576ea6aeac5beastmode.png','나는 귀염둥이',_binary '\0',11,6,_binary '\0',2),(48,'자몽허니블랙티\n맛있는데\n먹을래?','2023-11-17 10:07:27.610101','','',_binary '',6,5,_binary '',3),(49,'너 나 좋아하니?','2023-11-17 10:12:08.616495','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/a30d090c-1397-9eb8-159d-b19036e71d1aFECA2328-F128-42A5-9D6A-8B3798C1CD5A.jpeg','냥냥',_binary '\0',6,5,_binary '',2),(50,'뚜룹뚜뚜\n기다려주셔서 감사합니다 :)','2023-11-17 12:01:16.875160','https://star23shop-bucket.s3.ap-northeast-2.amazonaws.com/21a2f5f4-c6d9-f5f3-2ffb-02089153d447beastmode.png','저는 귀엽습니다',_binary '\0',11,6,_binary '\0',2),(51,'햄버거의 색깔은 무엇일까요?','2023-11-17 12:08:06.309701','','영어',_binary '\0',44,45,_binary '\0',2),(52,'안농 동주시 \n나는 너의 1004 .. ⭐\n나랑 놀아줘서 고마오 .. ? (ㅋㅋ)','2023-11-17 12:08:40.261637','','1004',_binary '\0',45,44,_binary '\0',3),(53,'안농 동주시 \n나는 너의 1004 .. ⭐\n나랑 놀아줘서 고마오 .. ? (ㅋㅋ)','2023-11-17 12:08:40.409869','','1004',_binary '\0',45,44,_binary '\0',3),(54,'햄버거의 색깔은?','2023-11-17 12:11:47.733049','','버건디ㅋㅋ',_binary '\0',44,45,_binary '\0',3);
/*!40000 ALTER TABLE `letters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 12:45:10
