CREATE DATABASE  IF NOT EXISTS `free` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `free`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 3.36.95.217    Database: free
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `note_id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `is_read` bit(1) NOT NULL,
  `is_reply` bit(1) NOT NULL,
  `is_store` bit(1) DEFAULT NULL,
  `receiver_id` bigint NOT NULL,
  `receiver_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_id` bigint NOT NULL,
  `sender_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `room_id` bigint NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `FK43el3rbnd57wik5cic2c0xkni` (`room_id`),
  CONSTRAINT `FK43el3rbnd57wik5cic2c0xkni` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (1,'어쩔티비 저쩔티비','2023-11-14 16:59:10.253121',_binary '',_binary '',_binary '',2,'뜨거운 병아리',1,'네모난 디멘터',1),(2,'이 편지는 영국에서 최초로 시작되어 일년에 한바퀴를 돌면서 받는 사람에게 행운을 주었고 지금은 당신에게로 옮겨진 이 편지는 4일 안에 당신 곁을 떠나야 합니다. 이 편지를 포함해서 7통을 행운이 필요한 사람에게 보내 주셔야 합니다. 복사를 해도 좋습니다. 혹 미신이라 하실지 모르지만 사실입니다.','2023-11-14 17:07:46.960287',_binary '',_binary '',_binary '',1,'이기적인 펭귄',4,'쿨한 표범',2),(3,'저메추 해주삼','2023-11-14 17:25:23.576196',_binary '',_binary '',_binary '',1,'새하얀 삽살개',9,'성실한 진돗개',3),(4,'하이하잉','2023-11-14 17:27:01.108716',_binary '\0',_binary '\0',_binary '',7,'파파보이 여우',10,'걱정하는 패럿',4),(5,'안녕 반가워 죽여줘','2023-11-14 17:32:46.886124',_binary '\0',_binary '\0',_binary '',10,'형편없는 사슴',11,'흥겨운 피글렛',5),(6,'안뇽 안뇽 ','2023-11-14 17:34:06.544199',_binary '\0',_binary '\0',_binary '',4,'꿈이많은 삽살개',2,'미세한 코끼리',6),(7,'누군가 보리라','2023-11-14 17:35:46.523133',_binary '\0',_binary '\0',_binary '',10,'파파걸 진돗개',13,'아늑한 코뿔소',7),(8,'이승민에게 협박을 당하고 있습니다. 살려주세요','2023-11-14 17:46:52.660352',_binary '\0',_binary '\0',_binary '',14,'뻥쟁이 공작새',15,'뇌절하는 고래',8),(9,'너무 예쁘셔요','2023-11-14 17:56:29.790852',_binary '\0',_binary '\0',_binary '',15,'칙칙한 돌고래',16,'안경쓴 고래',9),(10,'하이용 ㅋㅋ','2023-11-14 17:59:31.947878',_binary '\0',_binary '\0',_binary '',3,'섹시한 빅풋',17,'허스키한 돌고래',10),(11,'ssafy 끝나는 기분 우울..\n1년만 더 시켜주면 잘할게욯ㅋ','2023-11-14 18:13:52.425402',_binary '\0',_binary '\0',_binary '',17,'미간이넓은 자라',5,'간이큰 홍학',11),(12,'자율 파이팅','2023-11-14 19:39:14.821082',_binary '\0',_binary '\0',_binary '',17,'허스키한 낙타',24,'방구뀌는 염소',12),(13,'이 팀 UI 맛집이네~','2023-11-14 20:06:45.678038',_binary '',_binary '',_binary '',2,'엉엉우는 표범',25,'짜증나는 살모사',13),(14,'야 누구냐','2023-11-15 09:50:07.811383',_binary '',_binary '',_binary '',6,'기타치는 불사조',1,'젊은 족제비',14),(15,'안녀어어엉','2023-11-15 10:33:11.711355',_binary '\0',_binary '\0',_binary '',7,'아름다운 다람쥐',6,'만년꼴등 산토끼',15),(16,'안녕하세용','2023-11-15 14:34:06.216174',_binary '\0',_binary '\0',_binary '',29,'추운 하프물범',30,'옴므파탈 익룡',16),(17,'인천앞바다의 반대말은?\n인천엄마다','2023-11-15 14:36:07.688766',_binary '',_binary '',_binary '',1,'이마가넓은 백조',29,'세련된 알파카',17),(18,'뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스인가요뭐하는서비스','2023-11-15 14:44:57.218348',_binary '\0',_binary '\0',_binary '',7,'사악한 빅풋',31,'짓궂은 샐러맨더',18),(19,'화이팅~~~','2023-11-15 16:01:19.544745',_binary '\0',_binary '\0',_binary '',31,'설사쟁이 비둘기',32,'형편없는 개구리',19),(20,'안뇽하세여.....\n한 번 심심해서 작성해보는 편지입니다.. 지금 이걸 사용하고 계신 걸 보니 아마도 SSAFY 9기 분이실텐데 프로젝트 잘 마무리하시고 좋은 결과 있으시면 좋겠어용:)','2023-11-15 16:24:06.871717',_binary '\0',_binary '\0',_binary '',30,'소설쓰는 기러기',33,'심심한 낙타',20),(21,'이 편지는 한국에서 위싱시','2023-11-15 17:05:42.065461',_binary '\0',_binary '\0',_binary '',4,'쿨한 표범',1,'이기적인 펭귄',2),(22,'물이 귀엽게 안으면?\n물안경','2023-11-15 17:06:00.246285',_binary '\0',_binary '\0',_binary '',29,'세련된 알파카',1,'이마가넓은 백조',17),(23,'쓸데 없이 줄이지마 멍청한 놈아','2023-11-15 17:06:23.188136',_binary '',_binary '',_binary '',9,'성실한 진돗개',1,'새하얀 삽살개',3),(24,'오늘밤 당신의 간식을 훔쳐가겠습니다','2023-11-15 17:23:13.420805',_binary '',_binary '',_binary '',9,'기타치는 홍학',36,'휴가간 족제비',21),(25,'나는 서류 합격이 왜이리 안될까...ㅠㅠㅠㅠㅠ\n난 분명 잘 썼다고ㅡㅡ 진자 왜 날 안뽑는데 \n싸피 서류 가점 준다고 했잖아','2023-11-15 17:33:43.673825',_binary '\0',_binary '\0',_binary '',28,'섹시한 구렁이',1,'골골대는 코브라',22),(26,'안뇽 안뇽\n너의 오늘 하루는 어땠어??','2023-11-16 09:55:05.409103',_binary '\0',_binary '\0',_binary '',19,'칙칙한 휴먼',2,'심심한 곰',23),(27,'저쩔티비 어쩔티비','2023-11-16 09:56:04.275520',_binary '\0',_binary '\0',_binary '',1,'네모난 디멘터',2,'뜨거운 병아리',1),(28,'우하하 감사합니댱\n거기는 무슨 프로젝트 했나욤','2023-11-16 09:56:36.618285',_binary '\0',_binary '\0',_binary '',25,'짜증나는 살모사',2,'엉엉우는 표범',13),(29,'새로운메시징','2023-11-16 10:00:43.908265',_binary '',_binary '',_binary '',6,'손이매운 두더지',11,'눈이높은 부엉이',24),(31,'어제 공차 먹었는데\n너무 맛있었어요..\n밀크티 체고야 체고','2023-11-16 11:29:01.022459',_binary '',_binary '',_binary '',6,'설사쟁이 닭',5,'돈을훔치는 치타',26),(32,'너는 누구냐','2023-11-16 12:06:17.603565',_binary '',_binary '',_binary '',6,'걱정하는 당나귀',39,'똑똑한 바비루사',27),(33,'내곤 왜 안사됴','2023-11-16 14:57:18.369617',_binary '',_binary '',_binary '',5,'돈을훔치는 치타',6,'설사쟁이 닭',26),(34,'모야모야 넌 뭐야ㅡㅡ','2023-11-16 15:07:30.648623',_binary '\0',_binary '\0',_binary '',1,'젊은 족제비',6,'기타치는 불사조',14),(35,'Who are you?\n\nI\'m 000.\n\nI\'m 힘들어요 now.\n\n빨리 want 해요 휴식.\n\nProject 끝나면 즐거운 vacation 되세요.','2023-11-16 15:32:41.941006',_binary '',_binary '',_binary '',6,'정직한 메추라기',40,'손톱때가낀 자라',28),(36,'이 편지 받은 사람은 보라!\nhype-note.com 으로 가입하도록 하여라!','2023-11-16 16:07:17.785488',_binary '',_binary '',_binary '',6,'짜증나는 너구리',42,'우등생 갑오징어',29),(37,'나 좋아하는 여자애랑 밥도 먹고 영화도 보는데 이거 그린라이트일까?','2023-11-16 16:08:42.363271',_binary '',_binary '',_binary '',2,'만년1등 햄스터',41,'예민한 원숭이',30),(38,'마쟈! 그거 누가봐도 그린라이트야!!! ','2023-11-16 17:04:16.214524',_binary '\0',_binary '\0',_binary '',41,'예민한 원숭이',2,'만년1등 햄스터',30),(39,'싫어요 ! ','2023-11-16 17:12:31.076255',_binary '\0',_binary '\0',_binary '',42,'우등생 갑오징어',6,'짜증나는 너구리',29),(40,'나는 ... 조무래기','2023-11-16 17:12:45.020847',_binary '\0',_binary '\0',_binary '',39,'똑똑한 바비루사',6,'걱정하는 당나귀',27),(41,'좋아요 ..! ','2023-11-16 17:13:14.393483',_binary '\0',_binary '\0',_binary '',40,'손톱때가낀 자라',6,'정직한 메추라기',28),(42,'생강편 가져가','2023-11-16 17:13:43.036218',_binary '\0',_binary '\0',_binary '',36,'휴가간 족제비',9,'기타치는 홍학',21),(43,'ㅇㅉㄹㄱ~','2023-11-16 17:14:02.721850',_binary '\0',_binary '\0',_binary '',1,'새하얀 삽살개',9,'성실한 진돗개',3),(44,'답쟝답쟝','2023-11-16 17:14:15.134546',_binary '\0',_binary '\0',_binary '',11,'눈이높은 부엉이',6,'손이매운 두더지',24),(45,'나 오늘 프로젝트하는데 개빡쳤다ㅏ앙아아아아아아 \n진짜 세상 살기 힘들다 ..','2023-11-16 17:17:18.065194',_binary '\0',_binary '\0',_binary '',38,'쿠키를먹는 소',6,'눈이충혈된 토끼',31),(46,'왜냐면 나는 돈이 옵으니까 *(^o^)/* ','2023-11-17 09:12:39.414208',_binary '',_binary '',_binary '',6,'설사쟁이 닭',5,'돈을훔치는 치타',26),(47,'디지털 세상을 잇는 민들레 꽃씨가 되고싶다..','2023-11-17 09:16:21.334272',_binary '\0',_binary '\0',_binary '',6,'똑똑한 호랑이',41,'날아가는 물개',32),(48,'안뇽 안뇽\n저희 서비스에 만족하시나요?','2023-11-17 09:17:31.238884',_binary '\0',_binary '\0',_binary '',6,'칙칙한 도시쥐',2,'뻥쟁이 불사조',33),(49,'당신의 인생 명작\n책 영화 음악 아무거나 말해보세욤','2023-11-17 09:23:33.673002',_binary '\0',_binary '\0',_binary '',25,'욕심많은 빅풋',5,'고주망태인 토끼',34),(50,'나 오늘 엄청 화난능 일 있었어유ㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠ','2023-11-17 09:26:00.327618',_binary '\0',_binary '\0',_binary '',5,'옴므파탈 뱀',1,'불쌍한 삵',35),(51,'나 오늘 완즈이 떨렸다 !!!! ','2023-11-17 12:01:30.105924',_binary '\0',_binary '\0',_binary '\0',11,'앙증맞은 인면조',6,'젊은 기러기',36),(52,'배고파요','2023-11-17 12:03:01.815074',_binary '\0',_binary '\0',_binary '\0',20,'편안한 퓨마',36,'칙칙한 밍크',37),(53,'나 도 줘','2023-11-17 12:03:49.520047',_binary '\0',_binary '\0',_binary '\0',5,'돈을훔치는 치타',6,'설사쟁이 닭',26),(54,'외 않와','2023-11-17 12:10:26.047821',_binary '\0',_binary '\0',_binary '\0',17,'만년1등 악어',45,'카사노바 여우',38);
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 12:45:12
